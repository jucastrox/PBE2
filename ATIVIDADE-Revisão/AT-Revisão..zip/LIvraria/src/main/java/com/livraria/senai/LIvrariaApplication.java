package com.livraria.senai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LIvrariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LIvrariaApplication.class, args);
	}

}
