package com.livraria.senai.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.livraria.senai.controller.LivroController;
import com.livraria.senai.entitie.Livro;

public interface LivroRepository extends JpaRepository<LivroController, Long>{

	Livro save(Livro livro);

}
