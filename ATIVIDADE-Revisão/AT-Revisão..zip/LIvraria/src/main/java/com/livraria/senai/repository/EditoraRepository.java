package com.livraria.senai.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.livraria.senai.controller.EditoraController;
import com.livraria.senai.entitie.Editora;

public interface EditoraRepository extends JpaRepository<EditoraController, Long>{

	Editora save(Editora editora);


}