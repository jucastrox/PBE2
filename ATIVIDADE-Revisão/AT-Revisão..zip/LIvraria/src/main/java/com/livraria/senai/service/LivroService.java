package com.livraria.senai.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.livraria.senai.controller.LivroController;
import com.livraria.senai.entitie.Livro;
import com.livraria.senai.repository.LivroRepository;

@Service
public class LivroService {
    
    @Autowired
    private LivroRepository LivroRepository;
    
    public Livro saveLivro(Livro Livro) {
        return LivroRepository.save(Livro);
    }
    
    public List<LivroController> getAllLivros(){
        return LivroRepository.findAll();
    }
    public LivroController getLivroById (Long id_livro) {
        return LivroRepository.findById(id_livro).orElse(null);
    }
    public void deleteLivro(Long id_livro) {
        LivroRepository.deleteById(id_livro);
    }
	
}
